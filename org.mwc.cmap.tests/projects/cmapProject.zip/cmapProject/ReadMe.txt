The org.mwc.cmap.tests test requires that there is a some file opened
in the plotting editor. Because of that we have added the cmapProject project
(contains sample.xml). 

The project is created and the sample.xml file is opened in JUnit setUp method.
It enables that the org.mwc.cmap.test tests pass.