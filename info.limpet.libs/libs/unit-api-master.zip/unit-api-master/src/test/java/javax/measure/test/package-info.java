/**
 * 
 */
/**
 * @author Werner
 *
 */
package javax.measure.test;