EMF
---

To load or edit UML diagrams...
