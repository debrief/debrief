unit-api
========
[![Maven Central](https://maven-badges.herokuapp.com/maven-central/javax.measure/unit-api/badge.svg)](https://maven-badges.herokuapp.com/maven-central/javax.measure/unit-api)
[![Build Status](https://drone.io/github.com/unitsofmeasurement/unit-api/status.png)](https://drone.io/github.com/unitsofmeasurement/unit-api/latest)
[![Circle CI](https://circleci.com/gh/unitsofmeasurement/unit-api.svg?style=svg)](https://circleci.com/gh/unitsofmeasurement/unit-api)
[![Stack Overflow](http://img.shields.io/badge/stack%20overflow-uom-4183C4.svg)](http://stackoverflow.com/questions/tagged/units-of-measurement)
[![Join the chat at https://gitter.im/unitsofmeasurement/unit-api](https://badges.gitter.im/Join%20Chat.svg)](https://gitter.im/unitsofmeasurement/unit-api?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge)

JSR 363 - Units of Measurement API
