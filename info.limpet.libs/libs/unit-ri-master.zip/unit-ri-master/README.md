unit-ri
=======
[![Maven Central](https://maven-badges.herokuapp.com/maven-central/tec.units/unit-ri/badge.svg)](https://maven-badges.herokuapp.com/maven-central/tec.units/unit-ri)
[![Circle CI](https://circleci.com/gh/unitsofmeasurement/unit-ri.svg?style=svg)](https://circleci.com/gh/unitsofmeasurement/unit-ri) 
[![Build Status](https://drone.io/github.com/unitsofmeasurement/unit-ri/status.png)](https://drone.io/github.com/unitsofmeasurement/unit-ri/latest)
[![License](http://img.shields.io/badge/license-BSD3-blue.svg?style=flat-square)](http://opensource.org/licenses/BSD-3-Clause)
[![Join the chat at https://gitter.im/unitsofmeasurement/unit-ri](https://badges.gitter.im/Join%20Chat.svg)](https://gitter.im/unitsofmeasurement/unit-ri?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge)

JSR 363 Reference Implementation

The RI aims at **Java Embedded**, both *SE 7* or above and Java *ME 8 Embedded*
